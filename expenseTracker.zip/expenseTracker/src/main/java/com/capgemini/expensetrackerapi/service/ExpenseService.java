package com.capgemini.expensetrackerapi.service;

import java.util.List;

import com.capgemini.expensetrackerapi.entity.Expense;

public interface ExpenseService {
   List<Expense> getAllExpenses();
}
